﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateArena.Presentation.Core.Model
{
    public class BrainTeaserViewModel
    {
        public int UserID { get; set; }
        public int BrainTeaserID { get; set; }
    }
}
