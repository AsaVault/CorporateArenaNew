﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CorporateArena.Presentation
{
    public class CommentLikeViewModel
    {
        public int UserID { get; set; }
        public int ArticleID { get; set; }
        public int CommentID { get; set; }
    }
}
