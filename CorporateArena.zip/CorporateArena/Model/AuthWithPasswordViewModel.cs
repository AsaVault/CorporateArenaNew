﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CorporateArena.Presentation
{
    public class AuthWithPasswordViewModel
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
