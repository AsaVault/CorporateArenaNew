﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CorporateArena.Presentation
{
    public class AuthWithTokenViewModel
    {
        public string Token { get; set; }
    }
}
