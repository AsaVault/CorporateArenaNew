﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CorporateArena.Presentation
{
    public class SwaggerOpt
    {
        public string JsonRoute { get; set; }

        public string Description { get; set; }

        public string UIEndPoint { get; set; }
    }
}
